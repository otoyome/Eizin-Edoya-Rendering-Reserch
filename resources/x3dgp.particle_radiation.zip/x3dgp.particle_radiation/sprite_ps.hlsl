// UNIT.02
#include "sprite.hlsli"

// UNIT.05
Texture2D color_map : register(t0);
SamplerState point_sampler_state : register(s0);
SamplerState linear_sampler_state : register(s1);
SamplerState anisotropic_sampler_state : register(s2);

float4 main(VS_OUT pin) : SV_TARGET
{
	//return color_map.Sample(point_sampler_state, pin.texcoord) * pin.color;

	// UNIT.32
	float4 color = color_map.Sample(anisotropic_sampler_state, pin.texcoord);
	float alpha = color.a;

#if 1
	// Inverse gamma process
	const float GAMMA = 2.2;
	color.rgb = pow(color.rgb, GAMMA);
#endif

	return float4(color.rgb, alpha) * pin.color;
}

